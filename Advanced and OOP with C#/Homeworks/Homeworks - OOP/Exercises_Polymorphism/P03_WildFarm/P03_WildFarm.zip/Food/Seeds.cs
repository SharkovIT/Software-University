﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_WildFarm.Food
{
    public class Seeds : Food
    {
        public Seeds(int quantity)
            : base(quantity)
        {
        }
    }
}
