﻿namespace P03_Ferrari
{
    interface ICar
    {
        string UseBreaks();

        string PushTheGas();
    }
}
