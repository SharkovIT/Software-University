﻿namespace P05_BorderControl.Contracts
{
    public interface IIdentifier
    {
        string Id { get; }
    }
}
