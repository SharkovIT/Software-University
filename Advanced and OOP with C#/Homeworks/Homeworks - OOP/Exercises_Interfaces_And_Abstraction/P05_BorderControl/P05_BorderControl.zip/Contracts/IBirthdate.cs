﻿namespace P05_BorderControl.Contracts
{
    public interface IBirthdate
    {
        string Birthdate { get; }
    }
}
