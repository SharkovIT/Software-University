﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Data
{
    static class Configuration
    {
        internal static string ConnectionString = @"Server=DESKTOP-G9R4701\SQLEXPRESS;Database=Sales;Integrated Security=True;";
    }
}
