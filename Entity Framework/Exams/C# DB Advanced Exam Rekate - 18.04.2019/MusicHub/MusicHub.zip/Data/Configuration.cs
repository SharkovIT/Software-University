﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-G9R4701\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True";
    }
}
