﻿namespace VaporStore
{
	using AutoMapper;
    using System.Linq;
    using VaporStore.Data.Models;
    using VaporStore.DataProcessor.ImportDtos;

    public class VaporStoreProfile : Profile
	{
		// Configure your AutoMapper here if you wish to use it. If not, DO NOT DELETE THIS CLASS
		
	}
}